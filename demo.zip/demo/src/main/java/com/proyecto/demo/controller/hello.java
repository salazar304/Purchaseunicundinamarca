package com.proyecto.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class hello {

    @GetMapping("/index")
    public String helloWorld(Model model) {
        model.addAttribute("title", "Pets Shop");
        model.addAttribute("juguetes", "Juguetes");
        model.addAttribute("ropa", "Ropa");
        model.addAttribute("comida", "Comida");
        model.addAttribute("camas", "Camas");
        model.addAttribute("aseo", "Aseo");
        model.addAttribute("htmlcontent","<div class=\"item\"><div class=\"thumb\"><div class=\"hover-content\"><ul><li><a href=\"single-product.html\"><i class=\"fa fa-eye\"></i></a></li><li><a href=\"single-product.html\"><i class=\"fa fa-star\"></i></a></li><li><a href=\"single-product.html\"><i class=\"fa fa-shopping-cart\"></i></a></li></ul></div><img src=\"assets/images/camasprueba.jpg\" alt=\"\"></div><div class=\"down-content\"><h4>Air Force 1 X</h4><span>$90.00</span><ul class=\"stars\"><li><i class=\"fa fa-star\"></i></li><li><i class=\"fa fa-star\"></i></li><li><i class=\"fa fa-star\"></i></li><li><i class=\"fa fa-star\"></i></li><li><i class=\"fa fa-star\"></i></li></ul></div></div>\r\n" + //
                "");
        return "index";
    }
}
